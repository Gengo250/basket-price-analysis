# Resultado do experimento

No teste temporal: 3180 observações, 919 altas; precisão 0.390, recall 0.706, F1 0.503 e AP 0.523. Houve 1015 falsos positivos e 270 falsos negativos. O limiar 0.25 foi escolhido na validação anterior ao reajuste. Coeficientes são associações, não efeitos causais. A base não contém inflação nem fatores econômicos externos; mudanças de coleta e lacunas limitam a generalização.
